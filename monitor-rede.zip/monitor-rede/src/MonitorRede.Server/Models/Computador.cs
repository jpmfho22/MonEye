namespace MonitorRede.Server.Models;

public class Computador
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string EnderecoIp { get; set; } = string.Empty;
    public string SistemaOperacional { get; set; } = string.Empty;
    public DateTime PrimeiraComunicacao { get; set; }
    public DateTime UltimaComunicacao { get; set; }

    public List<Medicao> Medicoes { get; set; } = new();
    public List<Alerta> Alertas { get; set; } = new();
}
