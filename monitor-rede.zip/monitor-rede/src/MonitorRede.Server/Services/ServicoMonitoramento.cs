using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MonitorRede.Server.Data;
using MonitorRede.Server.Dtos;
using MonitorRede.Server.Models;

namespace MonitorRede.Server.Services;

public class ServicoMonitoramento
{
    private readonly MonitorDbContext _db;
    private readonly OpcoesMonitoramento _opcoes;

    public ServicoMonitoramento(MonitorDbContext db, IOptions<OpcoesMonitoramento> opcoes)
    {
        _db = db;
        _opcoes = opcoes.Value;
    }

    public async Task<int> RegistrarMedicaoAsync(MedicaoEntrada entrada, string ipRemoto, CancellationToken ct)
    {
        var nome = entrada.Nome.Trim().ToUpperInvariant();
        var agora = DateTime.UtcNow;

        var computador = await _db.Computadores.FirstOrDefaultAsync(c => c.Nome == nome, ct);
        if (computador is null)
        {
            computador = new Computador
            {
                Nome = nome,
                PrimeiraComunicacao = agora
            };
            _db.Computadores.Add(computador);
        }

        computador.EnderecoIp = string.IsNullOrWhiteSpace(entrada.EnderecoIp) ? ipRemoto : entrada.EnderecoIp;
        computador.SistemaOperacional = entrada.SistemaOperacional;
        computador.UltimaComunicacao = agora;

        var medicao = new Medicao
        {
            Computador = computador,
            DataHora = agora,
            CpuPercentual = Arredondar(entrada.CpuPercentual),
            MemoriaPercentual = Arredondar(entrada.MemoriaPercentual),
            MemoriaTotalMb = Arredondar(entrada.MemoriaTotalMb),
            MemoriaUsadaMb = Arredondar(entrada.MemoriaUsadaMb),
            DiscoPercentual = Arredondar(entrada.DiscoPercentual),
            DiscoTotalGb = Arredondar(entrada.DiscoTotalGb),
            DiscoUsadoGb = Arredondar(entrada.DiscoUsadoGb),
            TempoAtividadeSegundos = entrada.TempoAtividadeSegundos
        };

        _db.Medicoes.Add(medicao);

        await AvaliarAlertasAsync(computador, medicao, ct);
        await ResolverAlertaComunicacaoAsync(computador, agora, ct);

        await _db.SaveChangesAsync(ct);
        return computador.Id;
    }

    private async Task AvaliarAlertasAsync(Computador computador, Medicao medicao, CancellationToken ct)
    {
        await AvaliarRecursoAsync(computador, "CPU", medicao.CpuPercentual, _opcoes.LimiteCpu, medicao.DataHora, ct);
        await AvaliarRecursoAsync(computador, "MEMORIA", medicao.MemoriaPercentual, _opcoes.LimiteMemoria, medicao.DataHora, ct);
        await AvaliarRecursoAsync(computador, "DISCO", medicao.DiscoPercentual, _opcoes.LimiteDisco, medicao.DataHora, ct);
    }

    private async Task AvaliarRecursoAsync(Computador computador, string tipo, double valor, double limite, DateTime agora, CancellationToken ct)
    {
        var ativo = computador.Id == 0
            ? null
            : await _db.Alertas.FirstOrDefaultAsync(a => a.ComputadorId == computador.Id && a.Tipo == tipo && a.Ativo, ct);

        if (valor >= limite)
        {
            if (ativo is null)
            {
                _db.Alertas.Add(new Alerta
                {
                    Computador = computador,
                    Tipo = tipo,
                    Mensagem = $"Utilizacao de {tipo.ToLowerInvariant()} em {valor:0.0}% (limite {limite:0.0}%)",
                    Valor = valor,
                    DataHora = agora,
                    Ativo = true
                });
            }
            else
            {
                ativo.Valor = valor;
            }
        }
        else if (ativo is not null)
        {
            ativo.Ativo = false;
            ativo.DataHoraResolucao = agora;
        }
    }

    private async Task ResolverAlertaComunicacaoAsync(Computador computador, DateTime agora, CancellationToken ct)
    {
        if (computador.Id == 0) return;

        var alertas = await _db.Alertas
            .Where(a => a.ComputadorId == computador.Id && a.Tipo == "COMUNICACAO" && a.Ativo)
            .ToListAsync(ct);

        foreach (var alerta in alertas)
        {
            alerta.Ativo = false;
            alerta.DataHoraResolucao = agora;
        }
    }

    public async Task<List<ComputadorResumo>> ListarComputadoresAsync(CancellationToken ct)
    {
        var agora = DateTime.UtcNow;

        var computadores = await _db.Computadores
            .AsNoTracking()
            .OrderBy(c => c.Nome)
            .ToListAsync(ct);

        var ids = computadores.Select(c => c.Id).ToList();

        var ultimosIds = await _db.Medicoes
            .AsNoTracking()
            .Where(m => ids.Contains(m.ComputadorId))
            .GroupBy(m => m.ComputadorId)
            .Select(g => g.Max(m => m.Id))
            .ToListAsync(ct);

        var ultimas = await _db.Medicoes
            .AsNoTracking()
            .Where(m => ultimosIds.Contains(m.Id))
            .ToListAsync(ct);

        var alertas = await _db.Alertas
            .AsNoTracking()
            .Where(a => a.Ativo && ids.Contains(a.ComputadorId))
            .GroupBy(a => a.ComputadorId)
            .Select(g => new { ComputadorId = g.Key, Total = g.Count() })
            .ToListAsync(ct);

        return computadores.Select(c =>
        {
            var ultima = ultimas.FirstOrDefault(m => m.ComputadorId == c.Id);
            var segundos = (agora - c.UltimaComunicacao).TotalSeconds;
            var estado = segundos <= _opcoes.SegundosParaOffline ? "ONLINE" : "OFFLINE";

            return new ComputadorResumo(
                c.Id,
                c.Nome,
                c.EnderecoIp,
                c.SistemaOperacional,
                estado,
                c.UltimaComunicacao,
                Math.Round(segundos, 0),
                ultima?.CpuPercentual,
                ultima?.MemoriaPercentual,
                ultima?.DiscoPercentual,
                ultima?.TempoAtividadeSegundos,
                alertas.FirstOrDefault(a => a.ComputadorId == c.Id)?.Total ?? 0);
        }).ToList();
    }

    public async Task<VisaoGeral> ObterVisaoGeralAsync(CancellationToken ct)
    {
        var lista = await ListarComputadoresAsync(ct);
        var online = lista.Count(c => c.Estado == "ONLINE");
        var comDados = lista.Where(c => c.Estado == "ONLINE" && c.CpuPercentual.HasValue).ToList();

        return new VisaoGeral(
            lista.Count,
            online,
            lista.Count - online,
            lista.Sum(c => c.AlertasAtivos),
            comDados.Count == 0 ? 0 : Math.Round(comDados.Average(c => c.CpuPercentual!.Value), 1),
            comDados.Count == 0 ? 0 : Math.Round(comDados.Average(c => c.MemoriaPercentual!.Value), 1));
    }

    public async Task<List<MedicaoHistorico>> ObterHistoricoAsync(int computadorId, int horas, CancellationToken ct)
    {
        var limite = DateTime.UtcNow.AddHours(-horas);

        return await _db.Medicoes
            .AsNoTracking()
            .Where(m => m.ComputadorId == computadorId && m.DataHora >= limite)
            .OrderBy(m => m.DataHora)
            .Select(m => new MedicaoHistorico(
                m.DataHora,
                m.CpuPercentual,
                m.MemoriaPercentual,
                m.DiscoPercentual,
                m.TempoAtividadeSegundos))
            .ToListAsync(ct);
    }

    public async Task<List<AlertaSaida>> ListarAlertasAsync(bool somenteAtivos, int limite, CancellationToken ct)
    {
        var consulta = _db.Alertas.AsNoTracking().Include(a => a.Computador).AsQueryable();

        if (somenteAtivos)
            consulta = consulta.Where(a => a.Ativo);

        return await consulta
            .OrderByDescending(a => a.DataHora)
            .Take(limite)
            .Select(a => new AlertaSaida(
                a.Id,
                a.ComputadorId,
                a.Computador!.Nome,
                a.Tipo,
                a.Mensagem,
                a.Valor,
                a.DataHora,
                a.Ativo,
                a.DataHoraResolucao))
            .ToListAsync(ct);
    }

    public async Task<bool> RemoverComputadorAsync(int id, CancellationToken ct)
    {
        var computador = await _db.Computadores.FirstOrDefaultAsync(c => c.Id == id, ct);
        if (computador is null) return false;

        _db.Computadores.Remove(computador);
        await _db.SaveChangesAsync(ct);
        return true;
    }

    private static double Arredondar(double valor) => Math.Round(valor, 2);
}
