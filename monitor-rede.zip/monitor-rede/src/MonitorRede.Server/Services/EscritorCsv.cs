using System.Globalization;
using System.Text;

namespace MonitorRede.Server.Services;

public class EscritorCsv
{
    private readonly StreamWriter _escritor;
    private readonly char _separador;
    private readonly bool _decimalComVirgula;

    public EscritorCsv(StreamWriter escritor, char separador)
    {
        _escritor = escritor;
        _separador = separador;
        _decimalComVirgula = separador == ';';
    }

    public async Task EscreverLinhaAsync(params object?[] campos)
    {
        var construtor = new StringBuilder();

        for (var i = 0; i < campos.Length; i++)
        {
            if (i > 0) construtor.Append(_separador);
            construtor.Append(Formatar(campos[i]));
        }

        await _escritor.WriteLineAsync(construtor.ToString());
    }

    private string Formatar(object? campo)
    {
        var texto = campo switch
        {
            null => string.Empty,
            double numero => Numero(numero),
            float numero => Numero(numero),
            decimal numero => Numero((double)numero),
            DateTime data => data.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture),
            bool logico => logico ? "SIM" : "NAO",
            _ => Convert.ToString(campo, CultureInfo.InvariantCulture) ?? string.Empty
        };

        return Escapar(texto);
    }

    private string Numero(double valor)
    {
        var texto = valor.ToString("0.##", CultureInfo.InvariantCulture);
        return _decimalComVirgula ? texto.Replace('.', ',') : texto;
    }

    private string Escapar(string texto)
    {
        if (texto.IndexOf(_separador) < 0 &&
            texto.IndexOf('"') < 0 &&
            texto.IndexOf('\n') < 0 &&
            texto.IndexOf('\r') < 0)
            return texto;

        return $"\"{texto.Replace("\"", "\"\"")}\"";
    }
}
