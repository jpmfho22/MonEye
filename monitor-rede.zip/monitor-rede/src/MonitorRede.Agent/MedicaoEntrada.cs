namespace MonitorRede.Agent;

public record MedicaoEntrada(
    string Nome,
    string EnderecoIp,
    string SistemaOperacional,
    double CpuPercentual,
    double MemoriaPercentual,
    double MemoriaTotalMb,
    double MemoriaUsadaMb,
    double DiscoPercentual,
    double DiscoTotalGb,
    double DiscoUsadoGb,
    long TempoAtividadeSegundos);
