using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using Microsoft.Extensions.Options;

namespace MonitorRede.Agent;

public class ColetorMetricas : IDisposable
{
    private readonly OpcoesAgente _opcoes;
    private readonly ILogger<ColetorMetricas> _log;
    private PerformanceCounter? _contadorCpu;

    public ColetorMetricas(IOptions<OpcoesAgente> opcoes, ILogger<ColetorMetricas> log)
    {
        _opcoes = opcoes.Value;
        _log = log;

        if (OperatingSystem.IsWindows())
        {
            try
            {
                _contadorCpu = new PerformanceCounter("Processor", "% Processor Time", "_Total", true);
                _contadorCpu.NextValue();
            }
            catch (Exception ex)
            {
                _log.LogWarning(ex, "Contador de desempenho de CPU indisponivel, usando metodo alternativo");
                _contadorCpu = null;
            }
        }
    }

    public MedicaoEntrada Coletar()
    {
        var (memoriaTotalMb, memoriaDisponivelMb) = ObterMemoria();
        var memoriaUsadaMb = memoriaTotalMb - memoriaDisponivelMb;
        var memoriaPercentual = memoriaTotalMb > 0 ? memoriaUsadaMb / memoriaTotalMb * 100 : 0;

        var (discoTotalGb, discoLivreGb) = ObterDisco();
        var discoUsadoGb = discoTotalGb - discoLivreGb;
        var discoPercentual = discoTotalGb > 0 ? discoUsadoGb / discoTotalGb * 100 : 0;

        return new MedicaoEntrada(
            string.IsNullOrWhiteSpace(_opcoes.NomePersonalizado) ? Environment.MachineName : _opcoes.NomePersonalizado,
            ObterIpLocal(),
            RuntimeInformation.OSDescription,
            ObterCpu(),
            memoriaPercentual,
            memoriaTotalMb,
            memoriaUsadaMb,
            discoPercentual,
            discoTotalGb,
            discoUsadoGb,
            ObterTempoAtividade());
    }

    private double ObterCpu()
    {
        if (_contadorCpu is not null)
        {
            try
            {
                return Math.Clamp(_contadorCpu.NextValue(), 0, 100);
            }
            catch (Exception ex)
            {
                _log.LogWarning(ex, "Falha ao ler contador de CPU");
            }
        }

        return CalcularCpuPorProcessos();
    }

    private static double CalcularCpuPorProcessos()
    {
        var tempoInicial = TotalTempoProcessador();
        Thread.Sleep(500);
        var tempoFinal = TotalTempoProcessador();

        var delta = (tempoFinal - tempoInicial).TotalMilliseconds;
        var janela = 500.0 * Environment.ProcessorCount;

        return janela > 0 ? Math.Clamp(delta / janela * 100, 0, 100) : 0;
    }

    private static TimeSpan TotalTempoProcessador()
    {
        var total = TimeSpan.Zero;
        foreach (var processo in Process.GetProcesses())
        {
            try { total += processo.TotalProcessorTime; }
            catch { }
            finally { processo.Dispose(); }
        }
        return total;
    }

    private (double totalMb, double disponivelMb) ObterMemoria()
    {
        if (OperatingSystem.IsWindows())
        {
            var estado = new MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
            if (GlobalMemoryStatusEx(ref estado))
                return (estado.ullTotalPhys / 1024d / 1024d, estado.ullAvailPhys / 1024d / 1024d);
        }

        var info = GC.GetGCMemoryInfo();
        var total = info.TotalAvailableMemoryBytes / 1024d / 1024d;
        var usada = GC.GetTotalMemory(false) / 1024d / 1024d;
        return (total, Math.Max(total - usada, 0));
    }

    private (double totalGb, double livreGb) ObterDisco()
    {
        try
        {
            var caminho = string.IsNullOrWhiteSpace(_opcoes.UnidadeDisco)
                ? Path.GetPathRoot(Environment.SystemDirectory) ?? "/"
                : _opcoes.UnidadeDisco;

            var unidade = new DriveInfo(caminho);
            if (!unidade.IsReady) return (0, 0);

            return (unidade.TotalSize / 1024d / 1024d / 1024d, unidade.TotalFreeSpace / 1024d / 1024d / 1024d);
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Falha ao obter informacoes de disco");
            return (0, 0);
        }
    }

    private static long ObterTempoAtividade() => (long)(Environment.TickCount64 / 1000);

    private static string ObterIpLocal()
    {
        try
        {
            foreach (var adaptador in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (adaptador.OperationalStatus != OperationalStatus.Up) continue;
                if (adaptador.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;

                foreach (var endereco in adaptador.GetIPProperties().UnicastAddresses)
                {
                    if (endereco.Address.AddressFamily == AddressFamily.InterNetwork &&
                        !IPAddress.IsLoopback(endereco.Address))
                        return endereco.Address.ToString();
                }
            }
        }
        catch { }

        return string.Empty;
    }

    public void Dispose() => _contadorCpu?.Dispose();

    [StructLayout(LayoutKind.Sequential)]
    private struct MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);
}
