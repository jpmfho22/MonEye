#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$PastaInstalacao = "C:\Program Files\MonitorRede\Agente",
    [string]$NomeServico = "MonitorRedeAgent"
)

$ErrorActionPreference = "Stop"

if (Get-Service -Name $NomeServico -ErrorAction SilentlyContinue) {
    Stop-Service -Name $NomeServico -Force -ErrorAction SilentlyContinue
    sc.exe delete $NomeServico | Out-Null
    Start-Sleep -Seconds 2
    Write-Host "Servico removido." -ForegroundColor Green
}

if (Test-Path $PastaInstalacao) {
    Remove-Item $PastaInstalacao -Recurse -Force
    Write-Host "Pasta removida." -ForegroundColor Green
}

Write-Host "Desinstalacao concluida." -ForegroundColor Green
