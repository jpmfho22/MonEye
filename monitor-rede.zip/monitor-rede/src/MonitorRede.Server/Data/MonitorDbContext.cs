using Microsoft.EntityFrameworkCore;
using MonitorRede.Server.Models;

namespace MonitorRede.Server.Data;

public class MonitorDbContext : DbContext
{
    public MonitorDbContext(DbContextOptions<MonitorDbContext> options) : base(options)
    {
    }

    public DbSet<Computador> Computadores => Set<Computador>();
    public DbSet<Medicao> Medicoes => Set<Medicao>();
    public DbSet<Alerta> Alertas => Set<Alerta>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Computador>(e =>
        {
            e.HasIndex(c => c.Nome).IsUnique();
            e.Property(c => c.Nome).IsRequired().HasMaxLength(200);
            e.Property(c => c.EnderecoIp).HasMaxLength(60);
            e.Property(c => c.SistemaOperacional).HasMaxLength(200);
        });

        modelBuilder.Entity<Medicao>(e =>
        {
            e.HasIndex(m => new { m.ComputadorId, m.DataHora });
            e.HasOne(m => m.Computador)
                .WithMany(c => c.Medicoes)
                .HasForeignKey(m => m.ComputadorId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Alerta>(e =>
        {
            e.HasIndex(a => new { a.ComputadorId, a.Ativo });
            e.Property(a => a.Tipo).HasMaxLength(60);
            e.Property(a => a.Mensagem).HasMaxLength(400);
            e.HasOne(a => a.Computador)
                .WithMany(c => c.Alertas)
                .HasForeignKey(a => a.ComputadorId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
