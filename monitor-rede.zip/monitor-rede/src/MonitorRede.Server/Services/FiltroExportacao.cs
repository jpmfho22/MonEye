using System.Globalization;

namespace MonitorRede.Server.Services;

public class FiltroExportacao
{
    public DateTime InicioUtc { get; init; }
    public DateTime FimUtc { get; init; }
    public int? ComputadorId { get; init; }
    public string? Tipo { get; init; }
    public bool ApenasAtivos { get; init; }
    public char Separador { get; init; } = ';';

    public string SufixoArquivo =>
        $"{InicioUtc.ToLocalTime():yyyyMMdd}_{FimUtc.ToLocalTime().AddSeconds(-1):yyyyMMdd}";

    public static bool TentarCriar(
        string? inicio,
        string? fim,
        int? computadorId,
        string? tipo,
        bool apenasAtivos,
        string? separador,
        int diasPadrao,
        out FiltroExportacao filtro,
        out string erro)
    {
        filtro = new FiltroExportacao();
        erro = string.Empty;

        var agoraLocal = DateTime.Now;

        if (!TentarConverter(inicio, false, out var inicioLocal))
        {
            if (!string.IsNullOrWhiteSpace(inicio))
            {
                erro = "Data inicial invalida. Use o formato aaaa-MM-dd ou aaaa-MM-ddTHH:mm.";
                return false;
            }
            inicioLocal = agoraLocal.Date.AddDays(-diasPadrao);
        }

        if (!TentarConverter(fim, true, out var fimLocal))
        {
            if (!string.IsNullOrWhiteSpace(fim))
            {
                erro = "Data final invalida. Use o formato aaaa-MM-dd ou aaaa-MM-ddTHH:mm.";
                return false;
            }
            fimLocal = agoraLocal.Date.AddDays(1);
        }

        if (fimLocal <= inicioLocal)
        {
            erro = "A data final deve ser posterior a data inicial.";
            return false;
        }

        if ((fimLocal - inicioLocal).TotalDays > 400)
        {
            erro = "O periodo nao pode ultrapassar 400 dias.";
            return false;
        }

        filtro = new FiltroExportacao
        {
            InicioUtc = inicioLocal.ToUniversalTime(),
            FimUtc = fimLocal.ToUniversalTime(),
            ComputadorId = computadorId is > 0 ? computadorId : null,
            Tipo = string.IsNullOrWhiteSpace(tipo) ? null : tipo.Trim().ToUpperInvariant(),
            ApenasAtivos = apenasAtivos,
            Separador = string.Equals(separador, "virgula", StringComparison.OrdinalIgnoreCase) ? ',' : ';'
        };

        return true;
    }

    private static bool TentarConverter(string? valor, bool fimDeDia, out DateTime resultado)
    {
        resultado = default;
        if (string.IsNullOrWhiteSpace(valor)) return false;

        var texto = valor.Trim();

        if (DateTime.TryParseExact(texto, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var apenasData))
        {
            resultado = DateTime.SpecifyKind(fimDeDia ? apenasData.AddDays(1) : apenasData, DateTimeKind.Local);
            return true;
        }

        if (DateTime.TryParse(texto, CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeLocal, out var completa))
        {
            resultado = DateTime.SpecifyKind(completa, DateTimeKind.Local);
            return true;
        }

        return false;
    }
}
