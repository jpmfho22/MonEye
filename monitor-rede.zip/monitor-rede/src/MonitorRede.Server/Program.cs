using Microsoft.EntityFrameworkCore;
using MonitorRede.Server.Data;
using MonitorRede.Server.Endpoints;
using MonitorRede.Server.Services;

var builder = WebApplication.CreateBuilder(new WebApplicationOptions
{
    Args = args,
    ContentRootPath = AppContext.BaseDirectory
});

builder.Host.UseWindowsService(opcoes => opcoes.ServiceName = "MonitorRedeServer");

var pastaDados = Path.Combine(AppContext.BaseDirectory, "dados");
Directory.CreateDirectory(pastaDados);
var caminhoBanco = Path.Combine(pastaDados, "monitor.db");

builder.Services.Configure<OpcoesMonitoramento>(
    builder.Configuration.GetSection(OpcoesMonitoramento.Secao));

builder.Services.AddDbContext<MonitorDbContext>(opcoes =>
    opcoes.UseSqlite($"Data Source={caminhoBanco}"));

builder.Services.AddScoped<ServicoMonitoramento>();
builder.Services.AddScoped<ServicoExportacao>();
builder.Services.AddHostedService<VerificadorDisponibilidade>();
builder.Services.AddCors(opcoes =>
    opcoes.AddDefaultPolicy(politica => politica.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

using (var escopo = app.Services.CreateScope())
{
    var db = escopo.ServiceProvider.GetRequiredService<MonitorDbContext>();
    db.Database.EnsureCreated();
}

app.UseCors();
app.UseDefaultFiles();
app.UseStaticFiles();
app.MapearApi();

app.Run();
