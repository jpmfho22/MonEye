namespace MonitorRede.Server.Dtos;

public record MedicaoEntrada(
    string Nome,
    string EnderecoIp,
    string SistemaOperacional,
    double CpuPercentual,
    double MemoriaPercentual,
    double MemoriaTotalMb,
    double MemoriaUsadaMb,
    double DiscoPercentual,
    double DiscoTotalGb,
    double DiscoUsadoGb,
    long TempoAtividadeSegundos);

public record ComputadorResumo(
    int Id,
    string Nome,
    string EnderecoIp,
    string SistemaOperacional,
    string Estado,
    DateTime UltimaComunicacao,
    double SegundosSemComunicacao,
    double? CpuPercentual,
    double? MemoriaPercentual,
    double? DiscoPercentual,
    long? TempoAtividadeSegundos,
    int AlertasAtivos);

public record MedicaoHistorico(
    DateTime DataHora,
    double CpuPercentual,
    double MemoriaPercentual,
    double DiscoPercentual,
    long TempoAtividadeSegundos);

public record AlertaSaida(
    long Id,
    int ComputadorId,
    string Computador,
    string Tipo,
    string Mensagem,
    double Valor,
    DateTime DataHora,
    bool Ativo,
    DateTime? DataHoraResolucao);

public record VisaoGeral(
    int Total,
    int Online,
    int Offline,
    int AlertasAtivos,
    double CpuMedia,
    double MemoriaMedia);
