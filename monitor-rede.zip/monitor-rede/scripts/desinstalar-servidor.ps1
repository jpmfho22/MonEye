#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$PastaInstalacao = "C:\Program Files\MonitorRede\Servidor",
    [string]$NomeServico = "MonitorRedeServer",
    [switch]$ManterDados
)

$ErrorActionPreference = "Stop"

if (Get-Service -Name $NomeServico -ErrorAction SilentlyContinue) {
    Stop-Service -Name $NomeServico -Force -ErrorAction SilentlyContinue
    sc.exe delete $NomeServico | Out-Null
    Start-Sleep -Seconds 2
    Write-Host "Servico removido." -ForegroundColor Green
}

if ($ManterDados -and (Test-Path "$PastaInstalacao\dados")) {
    $backup = "$env:USERPROFILE\Desktop\MonitorRede-dados"
    Copy-Item "$PastaInstalacao\dados" $backup -Recurse -Force
    Write-Host "Banco de dados copiado para $backup" -ForegroundColor Yellow
}

if (Test-Path $PastaInstalacao) {
    Remove-Item $PastaInstalacao -Recurse -Force
    Write-Host "Pasta removida." -ForegroundColor Green
}

Get-NetFirewallRule -DisplayName "MonitorRede-*" -ErrorAction SilentlyContinue | Remove-NetFirewallRule
Write-Host "Desinstalacao concluida." -ForegroundColor Green
