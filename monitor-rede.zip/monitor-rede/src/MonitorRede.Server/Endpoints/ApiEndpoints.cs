using Microsoft.Extensions.Options;
using MonitorRede.Server.Dtos;
using MonitorRede.Server.Services;

namespace MonitorRede.Server.Endpoints;

public static class ApiEndpoints
{
    public static void MapearApi(this WebApplication app)
    {
        var api = app.MapGroup("/api");

        api.MapPost("/medicoes", async (
            MedicaoEntrada entrada,
            HttpContext contexto,
            ServicoMonitoramento servico,
            IOptions<OpcoesMonitoramento> opcoes,
            CancellationToken ct) =>
        {
            var chaveEsperada = opcoes.Value.ChaveAgente;
            var chaveRecebida = contexto.Request.Headers["X-Chave-Agente"].ToString();

            if (!string.IsNullOrWhiteSpace(chaveEsperada) && chaveRecebida != chaveEsperada)
                return Results.Unauthorized();

            if (string.IsNullOrWhiteSpace(entrada.Nome))
                return Results.BadRequest(new { erro = "Nome do computador obrigatorio" });

            var ipRemoto = contexto.Connection.RemoteIpAddress?.ToString() ?? string.Empty;
            var id = await servico.RegistrarMedicaoAsync(entrada, ipRemoto, ct);

            return Results.Ok(new { computadorId = id, recebidoEm = DateTime.UtcNow });
        });

        api.MapGet("/computadores", async (ServicoMonitoramento servico, CancellationToken ct) =>
            Results.Ok(await servico.ListarComputadoresAsync(ct)));

        api.MapGet("/computadores/{id:int}/historico", async (
            int id,
            int? horas,
            ServicoMonitoramento servico,
            CancellationToken ct) =>
            Results.Ok(await servico.ObterHistoricoAsync(id, horas is > 0 and <= 720 ? horas.Value : 6, ct)));

        api.MapDelete("/computadores/{id:int}", async (
            int id,
            ServicoMonitoramento servico,
            CancellationToken ct) =>
            await servico.RemoverComputadorAsync(id, ct) ? Results.NoContent() : Results.NotFound());

        api.MapGet("/alertas", async (
            bool? ativos,
            int? limite,
            ServicoMonitoramento servico,
            CancellationToken ct) =>
            Results.Ok(await servico.ListarAlertasAsync(ativos ?? true, limite is > 0 and <= 500 ? limite.Value : 100, ct)));

        api.MapGet("/visao-geral", async (ServicoMonitoramento servico, CancellationToken ct) =>
            Results.Ok(await servico.ObterVisaoGeralAsync(ct)));

        api.MapGet("/configuracao", (IOptions<OpcoesMonitoramento> opcoes) => Results.Ok(new
        {
            opcoes.Value.SegundosParaOffline,
            opcoes.Value.LimiteCpu,
            opcoes.Value.LimiteMemoria,
            opcoes.Value.LimiteDisco,
            opcoes.Value.DiasRetencaoHistorico
        }));

        api.MapGet("/saude", () => Results.Ok(new { estado = "ok", utc = DateTime.UtcNow }));

        MapearExportacao(api);
    }

    private static void MapearExportacao(RouteGroupBuilder api)
    {
        var exportacao = api.MapGroup("/exportacao");

        exportacao.MapGet("/medicoes.csv", async (
            string? inicio,
            string? fim,
            int? computadorId,
            string? separador,
            HttpContext contexto,
            ServicoExportacao servico,
            CancellationToken ct) =>
        {
            if (!FiltroExportacao.TentarCriar(inicio, fim, computadorId, null, false, separador, 7, out var filtro, out var erro))
                return Results.BadRequest(new { erro });

            contexto.Response.ContentType = "text/csv; charset=utf-8";
            contexto.Response.Headers.ContentDisposition =
                $"attachment; filename=medicoes_{filtro.SufixoArquivo}.csv";

            await servico.ExportarMedicoesAsync(contexto.Response.Body, filtro, ct);
            return Results.Empty;
        });

        exportacao.MapGet("/alertas.csv", async (
            string? inicio,
            string? fim,
            int? computadorId,
            string? tipo,
            bool? ativos,
            string? separador,
            HttpContext contexto,
            ServicoExportacao servico,
            CancellationToken ct) =>
        {
            if (!FiltroExportacao.TentarCriar(inicio, fim, computadorId, tipo, ativos ?? false, separador, 30, out var filtro, out var erro))
                return Results.BadRequest(new { erro });

            contexto.Response.ContentType = "text/csv; charset=utf-8";
            contexto.Response.Headers.ContentDisposition =
                $"attachment; filename=alertas_{filtro.SufixoArquivo}.csv";

            await servico.ExportarAlertasAsync(contexto.Response.Body, filtro, ct);
            return Results.Empty;
        });

        exportacao.MapGet("/previa", async (
            string? inicio,
            string? fim,
            int? computadorId,
            string? tipo,
            bool? ativos,
            ServicoExportacao servico,
            CancellationToken ct) =>
        {
            if (!FiltroExportacao.TentarCriar(inicio, fim, computadorId, tipo, ativos ?? false, null, 7, out var filtro, out var erro))
                return Results.BadRequest(new { erro });

            return Results.Ok(new
            {
                inicioUtc = filtro.InicioUtc,
                fimUtc = filtro.FimUtc,
                medicoes = await servico.ContarMedicoesAsync(filtro, ct),
                alertas = await servico.ContarAlertasAsync(filtro, ct)
            });
        });
    }
}
