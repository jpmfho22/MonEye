namespace MonitorRede.Server.Services;

public class OpcoesMonitoramento
{
    public const string Secao = "Monitoramento";

    public int SegundosParaOffline { get; set; } = 90;
    public double LimiteCpu { get; set; } = 90;
    public double LimiteMemoria { get; set; } = 90;
    public double LimiteDisco { get; set; } = 90;
    public int DiasRetencaoHistorico { get; set; } = 30;
    public string ChaveAgente { get; set; } = "monitor-rede-local";
}
