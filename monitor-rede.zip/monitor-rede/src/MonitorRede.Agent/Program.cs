using MonitorRede.Agent;

var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings
{
    Args = args,
    ContentRootPath = AppContext.BaseDirectory
});

builder.Services.AddWindowsService(opcoes => opcoes.ServiceName = "MonitorRedeAgent");
builder.Services.Configure<OpcoesAgente>(builder.Configuration.GetSection(OpcoesAgente.Secao));

var configuracao = builder.Configuration.GetSection(OpcoesAgente.Secao).Get<OpcoesAgente>() ?? new OpcoesAgente();

builder.Services.AddHttpClient("servidor", cliente =>
{
    cliente.BaseAddress = new Uri(configuracao.UrlServidor.TrimEnd('/'));
    cliente.Timeout = TimeSpan.FromSeconds(20);
    cliente.DefaultRequestHeaders.Add("X-Chave-Agente", configuracao.ChaveAgente);
});

builder.Services.AddSingleton<ColetorMetricas>();
builder.Services.AddHostedService<ServicoAgente>();

var host = builder.Build();
host.Run();
