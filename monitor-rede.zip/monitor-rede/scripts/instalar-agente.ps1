#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$UrlServidor,

    [string]$PastaInstalacao = "C:\Program Files\MonitorRede\Agente",
    [int]$IntervaloSegundos = 30,
    [string]$ChaveAgente = "monitor-rede-local",
    [string]$NomePersonalizado = "",
    [string]$UnidadeDisco = "C:\",
    [string]$NomeServico = "MonitorRedeAgent"
)

$ErrorActionPreference = "Stop"
$origem = $PSScriptRoot

if (Get-Service -Name $NomeServico -ErrorAction SilentlyContinue) {
    Write-Host "Agente existente encontrado, parando e removendo..." -ForegroundColor Yellow
    Stop-Service -Name $NomeServico -Force -ErrorAction SilentlyContinue
    sc.exe delete $NomeServico | Out-Null
    Start-Sleep -Seconds 2
}

New-Item -ItemType Directory -Path $PastaInstalacao -Force | Out-Null
Copy-Item "$origem\*" $PastaInstalacao -Recurse -Force -Exclude "*.ps1"

$configPath = Join-Path $PastaInstalacao "appsettings.json"
$config = Get-Content $configPath -Raw | ConvertFrom-Json
$config.Agente.UrlServidor = $UrlServidor.TrimEnd('/')
$config.Agente.IntervaloSegundos = $IntervaloSegundos
$config.Agente.ChaveAgente = $ChaveAgente
$config.Agente.NomePersonalizado = $NomePersonalizado
$config.Agente.UnidadeDisco = $UnidadeDisco
$config | ConvertTo-Json -Depth 10 | Set-Content $configPath -Encoding UTF8

$executavel = Join-Path $PastaInstalacao "MonitorRede.Agent.exe"

New-Service -Name $NomeServico `
    -BinaryPathName "`"$executavel`"" `
    -DisplayName "Monitor de Rede - Agente" `
    -Description "Coleta e envia indicadores de desempenho ao servidor de monitoramento" `
    -StartupType Automatic | Out-Null

sc.exe failure $NomeServico reset= 86400 actions= restart/30000/restart/60000/restart/60000 | Out-Null

Start-Service -Name $NomeServico
Start-Sleep -Seconds 3

$servico = Get-Service -Name $NomeServico

Write-Host ""
Write-Host "Agente instalado." -ForegroundColor Green
Write-Host "Computador : $env:COMPUTERNAME"
Write-Host "Servidor   : $UrlServidor"
Write-Host "Intervalo  : $IntervaloSegundos s"
Write-Host "Situacao   : $($servico.Status)"
