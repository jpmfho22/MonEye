namespace MonitorRede.Server.Models;

public class Medicao
{
    public long Id { get; set; }
    public int ComputadorId { get; set; }
    public Computador? Computador { get; set; }

    public DateTime DataHora { get; set; }
    public double CpuPercentual { get; set; }
    public double MemoriaPercentual { get; set; }
    public double MemoriaTotalMb { get; set; }
    public double MemoriaUsadaMb { get; set; }
    public double DiscoPercentual { get; set; }
    public double DiscoTotalGb { get; set; }
    public double DiscoUsadoGb { get; set; }
    public long TempoAtividadeSegundos { get; set; }
}
