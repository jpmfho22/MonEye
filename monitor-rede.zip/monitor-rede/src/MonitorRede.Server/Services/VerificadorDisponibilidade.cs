using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MonitorRede.Server.Data;
using MonitorRede.Server.Models;

namespace MonitorRede.Server.Services;

public class VerificadorDisponibilidade : BackgroundService
{
    private readonly IServiceScopeFactory _fabrica;
    private readonly OpcoesMonitoramento _opcoes;
    private readonly ILogger<VerificadorDisponibilidade> _log;

    public VerificadorDisponibilidade(
        IServiceScopeFactory fabrica,
        IOptions<OpcoesMonitoramento> opcoes,
        ILogger<VerificadorDisponibilidade> log)
    {
        _fabrica = fabrica;
        _opcoes = opcoes.Value;
        _log = log;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ExecutarCicloAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "Falha no ciclo de verificacao de disponibilidade");
            }

            await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
        }
    }

    private async Task ExecutarCicloAsync(CancellationToken ct)
    {
        using var escopo = _fabrica.CreateScope();
        var db = escopo.ServiceProvider.GetRequiredService<MonitorDbContext>();

        var agora = DateTime.UtcNow;
        var corte = agora.AddSeconds(-_opcoes.SegundosParaOffline);

        var offline = await db.Computadores
            .Where(c => c.UltimaComunicacao < corte)
            .ToListAsync(ct);

        foreach (var computador in offline)
        {
            var jaExiste = await db.Alertas
                .AnyAsync(a => a.ComputadorId == computador.Id && a.Tipo == "COMUNICACAO" && a.Ativo, ct);

            if (jaExiste) continue;

            db.Alertas.Add(new Alerta
            {
                ComputadorId = computador.Id,
                Tipo = "COMUNICACAO",
                Mensagem = $"Sem comunicacao desde {computador.UltimaComunicacao:dd/MM/yyyy HH:mm:ss} (UTC)",
                Valor = Math.Round((agora - computador.UltimaComunicacao).TotalSeconds, 0),
                DataHora = agora,
                Ativo = true
            });
        }

        var limiteHistorico = agora.AddDays(-_opcoes.DiasRetencaoHistorico);
        var antigas = await db.Medicoes.Where(m => m.DataHora < limiteHistorico).Take(5000).ToListAsync(ct);
        if (antigas.Count > 0)
            db.Medicoes.RemoveRange(antigas);

        await db.SaveChangesAsync(ct);
    }
}
