const estado = {
  computadores: [],
  filtro: "",
  computadorSelecionado: null
};

const el = (id) => document.getElementById(id);

function formatarTempo(segundos) {
  if (segundos === null || segundos === undefined) return "--";
  const dias = Math.floor(segundos / 86400);
  const horas = Math.floor((segundos % 86400) / 3600);
  const minutos = Math.floor((segundos % 3600) / 60);
  if (dias > 0) return `${dias}d ${horas}h ${minutos}m`;
  if (horas > 0) return `${horas}h ${minutos}m`;
  return `${minutos}m`;
}

function formatarData(valor) {
  if (!valor) return "--";
  const data = new Date(valor.endsWith("Z") ? valor : valor + "Z");
  return data.toLocaleString("pt-BR");
}

function classeBarra(valor) {
  if (valor >= 90) return "alto";
  if (valor >= 70) return "medio";
  return "";
}

function celulaPercentual(valor) {
  if (valor === null || valor === undefined) return "<td>--</td>";
  return `<td>${valor.toFixed(1)}%<div class="barra"><span class="${classeBarra(valor)}" style="width:${Math.min(valor, 100)}%"></span></div></td>`;
}

async function carregarVisaoGeral() {
  const resposta = await fetch("/api/visao-geral");
  const dados = await resposta.json();
  el("kpiTotal").textContent = dados.total;
  el("kpiOnline").textContent = dados.online;
  el("kpiOffline").textContent = dados.offline;
  el("kpiAlertas").textContent = dados.alertasAtivos;
  el("kpiCpu").textContent = `${dados.cpuMedia.toFixed(1)}%`;
  el("kpiMemoria").textContent = `${dados.memoriaMedia.toFixed(1)}%`;
}

async function carregarComputadores() {
  const resposta = await fetch("/api/computadores");
  estado.computadores = await resposta.json();
  desenharComputadores();
}

function desenharComputadores() {
  const termo = estado.filtro.toLowerCase();
  const lista = estado.computadores.filter(c =>
    c.nome.toLowerCase().includes(termo) || (c.enderecoIp || "").toLowerCase().includes(termo));

  const corpo = el("corpoTabela");
  corpo.innerHTML = lista.map(c => `
    <tr>
      <td><span class="selo ${c.estado.toLowerCase()}">${c.estado}</span></td>
      <td><strong>${c.nome}</strong></td>
      <td>${c.enderecoIp || "--"}</td>
      ${celulaPercentual(c.cpuPercentual)}
      ${celulaPercentual(c.memoriaPercentual)}
      ${celulaPercentual(c.discoPercentual)}
      <td>${formatarTempo(c.tempoAtividadeSegundos)}</td>
      <td>${formatarData(c.ultimaComunicacao)}</td>
      <td>${c.alertasAtivos > 0 ? `<span class="selo ativo">${c.alertasAtivos}</span>` : "0"}</td>
      <td>
        <button class="botao secundario" data-historico="${c.id}" data-nome="${c.nome}">Historico</button>
        <button class="botao perigo" data-remover="${c.id}" data-nome="${c.nome}">Remover</button>
      </td>
    </tr>`).join("");

  el("vazio").style.display = lista.length ? "none" : "block";
  sincronizarSeletorExportacao();
}

function sincronizarSeletorExportacao() {
  const seletor = el("computadorExport");
  const selecionado = seletor.value;

  seletor.innerHTML = '<option value="">Todos</option>' +
    estado.computadores.map(c => `<option value="${c.id}">${c.nome}</option>`).join("");

  if (estado.computadores.some(c => String(c.id) === selecionado))
    seletor.value = selecionado;
}

async function carregarAlertas() {
  const ativos = el("somenteAtivos").checked;
  const resposta = await fetch(`/api/alertas?ativos=${ativos}&limite=100`);
  const alertas = await resposta.json();

  el("corpoAlertas").innerHTML = alertas.map(a => `
    <tr>
      <td><span class="selo ${a.ativo ? "ativo" : "resolvido"}">${a.ativo ? "ATIVO" : "RESOLVIDO"}</span></td>
      <td>${a.computador}</td>
      <td>${a.tipo}</td>
      <td style="white-space:normal">${a.mensagem}</td>
      <td>${formatarData(a.dataHora)}</td>
    </tr>`).join("");

  el("vazioAlertas").style.display = alertas.length ? "none" : "block";
}

function desenharGrafico(canvas, pontos, cor) {
  const ctx = canvas.getContext("2d");
  const largura = canvas.width = canvas.clientWidth;
  const altura = canvas.height;
  ctx.clearRect(0, 0, largura, altura);

  const margem = 28;
  const areaL = largura - margem * 2;
  const areaA = altura - margem * 1.4;

  ctx.strokeStyle = "#2a3447";
  ctx.fillStyle = "#94a1b8";
  ctx.font = "10px Segoe UI";
  ctx.lineWidth = 1;

  for (let i = 0; i <= 4; i++) {
    const y = margem * 0.7 + (areaA / 4) * i;
    ctx.beginPath();
    ctx.moveTo(margem, y);
    ctx.lineTo(largura - margem * 0.5, y);
    ctx.stroke();
    ctx.fillText(`${100 - i * 25}%`, 4, y + 3);
  }

  if (!pontos.length) return;

  const passo = pontos.length > 1 ? areaL / (pontos.length - 1) : 0;
  const coordenadas = pontos.map((valor, indice) => [
    margem + passo * indice,
    margem * 0.7 + areaA - (Math.min(valor, 100) / 100) * areaA
  ]);

  const degrade = ctx.createLinearGradient(0, margem, 0, altura);
  degrade.addColorStop(0, cor + "55");
  degrade.addColorStop(1, cor + "00");

  ctx.beginPath();
  ctx.moveTo(coordenadas[0][0], margem * 0.7 + areaA);
  coordenadas.forEach(([x, y]) => ctx.lineTo(x, y));
  ctx.lineTo(coordenadas[coordenadas.length - 1][0], margem * 0.7 + areaA);
  ctx.closePath();
  ctx.fillStyle = degrade;
  ctx.fill();

  ctx.beginPath();
  coordenadas.forEach(([x, y], i) => i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y));
  ctx.strokeStyle = cor;
  ctx.lineWidth = 2;
  ctx.stroke();
}

async function abrirHistorico(id, nome) {
  estado.computadorSelecionado = { id, nome };
  el("modalTitulo").textContent = `Historico - ${nome}`;
  el("modal").classList.remove("oculto");
  await carregarHistorico();
}

async function carregarHistorico() {
  if (!estado.computadorSelecionado) return;
  const horas = el("janela").value;
  const resposta = await fetch(`/api/computadores/${estado.computadorSelecionado.id}/historico?horas=${horas}`);
  const dados = await resposta.json();

  el("historicoVazio").style.display = dados.length ? "none" : "block";

  desenharGrafico(el("graficoCpu"), dados.map(d => d.cpuPercentual), "#4c8dff");
  desenharGrafico(el("graficoMemoria"), dados.map(d => d.memoriaPercentual), "#2fbf71");
  desenharGrafico(el("graficoDisco"), dados.map(d => d.discoPercentual), "#f0b429");
}

async function removerComputador(id, nome) {
  if (!confirm(`Remover ${nome} e todo o historico registrado?`)) return;
  await fetch(`/api/computadores/${id}`, { method: "DELETE" });
  await atualizarTudo();
}

async function atualizarTudo() {
  try {
    await Promise.all([carregarVisaoGeral(), carregarComputadores(), carregarAlertas()]);
    el("atualizadoEm").textContent = `Atualizado em ${new Date().toLocaleTimeString("pt-BR")}`;
  } catch {
    el("atualizadoEm").textContent = "Falha ao comunicar com o servidor";
  }
}

document.addEventListener("click", (evento) => {
  const historico = evento.target.closest("[data-historico]");
  if (historico) abrirHistorico(historico.dataset.historico, historico.dataset.nome);

  const remover = evento.target.closest("[data-remover]");
  if (remover) removerComputador(remover.dataset.remover, remover.dataset.nome);
});

el("btnAtualizar").addEventListener("click", atualizarTudo);
el("btnFechar").addEventListener("click", () => {
  el("modal").classList.add("oculto");
  estado.computadorSelecionado = null;
});
el("janela").addEventListener("change", carregarHistorico);
el("somenteAtivos").addEventListener("change", carregarAlertas);
el("filtro").addEventListener("input", (e) => {
  estado.filtro = e.target.value;
  desenharComputadores();
});

function parametrosExportacao(incluirTipo) {
  const parametros = new URLSearchParams();
  const inicio = el("dataInicio").value;
  const fim = el("dataFim").value;
  const computador = el("computadorExport").value;

  if (inicio) parametros.set("inicio", inicio);
  if (fim) parametros.set("fim", fim);
  if (computador) parametros.set("computadorId", computador);
  if (incluirTipo && el("tipoAlerta").value) parametros.set("tipo", el("tipoAlerta").value);

  return parametros;
}

async function atualizarPrevia() {
  const alvo = el("previaExportacao");
  const parametros = parametrosExportacao(true);

  try {
    const resposta = await fetch(`/api/exportacao/previa?${parametros}`);
    const dados = await resposta.json();

    if (!resposta.ok) {
      alvo.textContent = dados.erro || "Periodo invalido";
      alvo.classList.add("erro");
      return;
    }

    alvo.classList.remove("erro");
    alvo.textContent = `${dados.medicoes} medicoes e ${dados.alertas} alertas no periodo`;
  } catch {
    alvo.textContent = "--";
  }
}

function baixarCsv(rota, incluirTipo) {
  const parametros = parametrosExportacao(incluirTipo);
  parametros.set("separador", el("separador").value);
  window.location.href = `/api/exportacao/${rota}?${parametros}`;
}

el("btnMedicoesCsv").addEventListener("click", () => baixarCsv("medicoes.csv", false));
el("btnAlertasCsv").addEventListener("click", () => baixarCsv("alertas.csv", true));

["dataInicio", "dataFim", "computadorExport", "tipoAlerta"].forEach(id =>
  el(id).addEventListener("change", atualizarPrevia));

function definirPeriodoPadrao() {
  const hoje = new Date();
  const inicio = new Date();
  inicio.setDate(hoje.getDate() - 6);

  const formatar = (d) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

  el("dataInicio").value = formatar(inicio);
  el("dataFim").value = formatar(hoje);
}

definirPeriodoPadrao();
atualizarTudo().then(atualizarPrevia);
setInterval(atualizarTudo, 15000);
