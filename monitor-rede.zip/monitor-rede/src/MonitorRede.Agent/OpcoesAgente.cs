namespace MonitorRede.Agent;

public class OpcoesAgente
{
    public const string Secao = "Agente";

    public string UrlServidor { get; set; } = "http://localhost:5080";
    public int IntervaloSegundos { get; set; } = 30;
    public string ChaveAgente { get; set; } = "monitor-rede-local";
    public string NomePersonalizado { get; set; } = string.Empty;
    public string UnidadeDisco { get; set; } = "C:\\";
}
