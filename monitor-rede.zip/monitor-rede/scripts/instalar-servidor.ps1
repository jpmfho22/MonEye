#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$PastaInstalacao = "C:\Program Files\MonitorRede\Servidor",
    [int]$Porta = 5080,
    [string]$NomeServico = "MonitorRedeServer"
)

$ErrorActionPreference = "Stop"
$origem = $PSScriptRoot

if (Get-Service -Name $NomeServico -ErrorAction SilentlyContinue) {
    Write-Host "Servico existente encontrado, parando e removendo..." -ForegroundColor Yellow
    Stop-Service -Name $NomeServico -Force -ErrorAction SilentlyContinue
    sc.exe delete $NomeServico | Out-Null
    Start-Sleep -Seconds 2
}

New-Item -ItemType Directory -Path $PastaInstalacao -Force | Out-Null
Copy-Item "$origem\*" $PastaInstalacao -Recurse -Force -Exclude "*.ps1"

$configPath = Join-Path $PastaInstalacao "appsettings.json"
$config = Get-Content $configPath -Raw | ConvertFrom-Json
$config.Urls = "http://0.0.0.0:$Porta"
$config | ConvertTo-Json -Depth 10 | Set-Content $configPath -Encoding UTF8

$executavel = Join-Path $PastaInstalacao "MonitorRede.Server.exe"

New-Service -Name $NomeServico `
    -BinaryPathName "`"$executavel`"" `
    -DisplayName "Monitor de Rede - Servidor" `
    -Description "Servidor central de monitoramento de computadores em rede local" `
    -StartupType Automatic | Out-Null

$regra = "MonitorRede-$Porta"
if (-not (Get-NetFirewallRule -DisplayName $regra -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName $regra -Direction Inbound -Protocol TCP -LocalPort $Porta -Action Allow | Out-Null
    Write-Host "Regra de firewall criada para a porta $Porta" -ForegroundColor Green
}

Start-Service -Name $NomeServico
Start-Sleep -Seconds 3

$ips = (Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" }).IPAddress

Write-Host ""
Write-Host "Servidor instalado e em execucao." -ForegroundColor Green
Write-Host "Painel local : http://localhost:$Porta"
foreach ($ip in $ips) { Write-Host "Painel rede  : http://${ip}:$Porta" }
Write-Host "Pasta        : $PastaInstalacao"
