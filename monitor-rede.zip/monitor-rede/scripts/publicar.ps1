#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$Saida = "$PSScriptRoot\..\publicado"
)

$ErrorActionPreference = "Stop"
$raiz = Resolve-Path "$PSScriptRoot\.."

Write-Host "Publicando MonitorRede..." -ForegroundColor Cyan

$destinoServidor = Join-Path $Saida "servidor"
$destinoAgente   = Join-Path $Saida "agente"

dotnet publish "$raiz\src\MonitorRede.Server\MonitorRede.Server.csproj" `
    -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
    -o $destinoServidor

dotnet publish "$raiz\src\MonitorRede.Agent\MonitorRede.Agent.csproj" `
    -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
    -o $destinoAgente

Copy-Item "$raiz\scripts\instalar-servidor.ps1" $destinoServidor -Force
Copy-Item "$raiz\scripts\desinstalar-servidor.ps1" $destinoServidor -Force
Copy-Item "$raiz\scripts\instalar-agente.ps1" $destinoAgente -Force
Copy-Item "$raiz\scripts\desinstalar-agente.ps1" $destinoAgente -Force

Write-Host ""
Write-Host "Concluido." -ForegroundColor Green
Write-Host "Servidor: $destinoServidor"
Write-Host "Agente:   $destinoAgente"
