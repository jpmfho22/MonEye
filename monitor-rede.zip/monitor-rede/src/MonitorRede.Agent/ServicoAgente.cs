using System.Net.Http.Json;
using Microsoft.Extensions.Options;

namespace MonitorRede.Agent;

public class ServicoAgente : BackgroundService
{
    private readonly IHttpClientFactory _fabrica;
    private readonly ColetorMetricas _coletor;
    private readonly OpcoesAgente _opcoes;
    private readonly ILogger<ServicoAgente> _log;

    public ServicoAgente(
        IHttpClientFactory fabrica,
        ColetorMetricas coletor,
        IOptions<OpcoesAgente> opcoes,
        ILogger<ServicoAgente> log)
    {
        _fabrica = fabrica;
        _coletor = coletor;
        _opcoes = opcoes.Value;
        _log = log;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _log.LogInformation("Agente iniciado. Servidor: {Servidor} | Intervalo: {Intervalo}s",
            _opcoes.UrlServidor, _opcoes.IntervaloSegundos);

        var intervalo = TimeSpan.FromSeconds(Math.Max(_opcoes.IntervaloSegundos, 5));

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var medicao = _coletor.Coletar();
                await EnviarAsync(medicao, stoppingToken);

                _log.LogInformation("Enviado - CPU {Cpu:0.0}% | MEM {Mem:0.0}% | DISCO {Disco:0.0}%",
                    medicao.CpuPercentual, medicao.MemoriaPercentual, medicao.DiscoPercentual);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _log.LogWarning("Falha ao enviar medicao: {Mensagem}", ex.Message);
            }

            try
            {
                await Task.Delay(intervalo, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }

        _log.LogInformation("Agente finalizado");
    }

    private async Task EnviarAsync(MedicaoEntrada medicao, CancellationToken ct)
    {
        var cliente = _fabrica.CreateClient("servidor");
        var resposta = await cliente.PostAsJsonAsync("/api/medicoes", medicao, ct);

        if (!resposta.IsSuccessStatusCode)
            throw new HttpRequestException($"Servidor respondeu {(int)resposta.StatusCode}");
    }
}
