using System.Text;
using Microsoft.EntityFrameworkCore;
using MonitorRede.Server.Data;

namespace MonitorRede.Server.Services;

public class ServicoExportacao
{
    private const int TamanhoLote = 500;

    private readonly MonitorDbContext _db;

    public ServicoExportacao(MonitorDbContext db)
    {
        _db = db;
    }

    public async Task ExportarMedicoesAsync(Stream destino, FiltroExportacao filtro, CancellationToken ct)
    {
        await using var escritor = CriarEscritor(destino);
        var csv = new EscritorCsv(escritor, filtro.Separador);

        await csv.EscreverLinhaAsync(
            "DataHoraUtc", "Computador", "EnderecoIp", "CpuPercentual",
            "MemoriaPercentual", "MemoriaUsadaMb", "MemoriaTotalMb",
            "DiscoPercentual", "DiscoUsadoGb", "DiscoTotalGb",
            "TempoAtividadeSegundos", "TempoAtividadeFormatado");

        var consulta = _db.Medicoes
            .AsNoTracking()
            .Include(m => m.Computador)
            .Where(m => m.DataHora >= filtro.InicioUtc && m.DataHora < filtro.FimUtc);

        if (filtro.ComputadorId is not null)
            consulta = consulta.Where(m => m.ComputadorId == filtro.ComputadorId);

        var contador = 0;

        await foreach (var medicao in consulta
            .OrderBy(m => m.DataHora)
            .ThenBy(m => m.Id)
            .AsAsyncEnumerable()
            .WithCancellation(ct))
        {
            await csv.EscreverLinhaAsync(
                medicao.DataHora,
                medicao.Computador?.Nome ?? string.Empty,
                medicao.Computador?.EnderecoIp ?? string.Empty,
                medicao.CpuPercentual,
                medicao.MemoriaPercentual,
                medicao.MemoriaUsadaMb,
                medicao.MemoriaTotalMb,
                medicao.DiscoPercentual,
                medicao.DiscoUsadoGb,
                medicao.DiscoTotalGb,
                medicao.TempoAtividadeSegundos,
                FormatarTempo(medicao.TempoAtividadeSegundos));

            if (++contador % TamanhoLote == 0)
                await escritor.FlushAsync(ct);
        }

        await escritor.FlushAsync(ct);
    }

    public async Task ExportarAlertasAsync(Stream destino, FiltroExportacao filtro, CancellationToken ct)
    {
        await using var escritor = CriarEscritor(destino);
        var csv = new EscritorCsv(escritor, filtro.Separador);

        await csv.EscreverLinhaAsync(
            "DataHoraUtc", "Computador", "EnderecoIp", "Tipo", "Mensagem",
            "Valor", "Ativo", "DataHoraResolucaoUtc", "DuracaoSegundos", "DuracaoFormatada");

        var consulta = _db.Alertas
            .AsNoTracking()
            .Include(a => a.Computador)
            .Where(a => a.DataHora >= filtro.InicioUtc && a.DataHora < filtro.FimUtc);

        if (filtro.ComputadorId is not null)
            consulta = consulta.Where(a => a.ComputadorId == filtro.ComputadorId);

        if (filtro.Tipo is not null)
            consulta = consulta.Where(a => a.Tipo == filtro.Tipo);

        if (filtro.ApenasAtivos)
            consulta = consulta.Where(a => a.Ativo);

        var agora = DateTime.UtcNow;
        var contador = 0;

        await foreach (var alerta in consulta
            .OrderBy(a => a.DataHora)
            .ThenBy(a => a.Id)
            .AsAsyncEnumerable()
            .WithCancellation(ct))
        {
            var fim = alerta.DataHoraResolucao ?? agora;
            var duracao = (long)Math.Max((fim - alerta.DataHora).TotalSeconds, 0);

            await csv.EscreverLinhaAsync(
                alerta.DataHora,
                alerta.Computador?.Nome ?? string.Empty,
                alerta.Computador?.EnderecoIp ?? string.Empty,
                alerta.Tipo,
                alerta.Mensagem,
                alerta.Valor,
                alerta.Ativo,
                alerta.DataHoraResolucao,
                duracao,
                FormatarTempo(duracao));

            if (++contador % TamanhoLote == 0)
                await escritor.FlushAsync(ct);
        }

        await escritor.FlushAsync(ct);
    }

    public async Task<int> ContarMedicoesAsync(FiltroExportacao filtro, CancellationToken ct)
    {
        var consulta = _db.Medicoes
            .AsNoTracking()
            .Where(m => m.DataHora >= filtro.InicioUtc && m.DataHora < filtro.FimUtc);

        if (filtro.ComputadorId is not null)
            consulta = consulta.Where(m => m.ComputadorId == filtro.ComputadorId);

        return await consulta.CountAsync(ct);
    }

    public async Task<int> ContarAlertasAsync(FiltroExportacao filtro, CancellationToken ct)
    {
        var consulta = _db.Alertas
            .AsNoTracking()
            .Where(a => a.DataHora >= filtro.InicioUtc && a.DataHora < filtro.FimUtc);

        if (filtro.ComputadorId is not null)
            consulta = consulta.Where(a => a.ComputadorId == filtro.ComputadorId);

        if (filtro.Tipo is not null)
            consulta = consulta.Where(a => a.Tipo == filtro.Tipo);

        if (filtro.ApenasAtivos)
            consulta = consulta.Where(a => a.Ativo);

        return await consulta.CountAsync(ct);
    }

    private static StreamWriter CriarEscritor(Stream destino) =>
        new(destino, new UTF8Encoding(true), 8192, leaveOpen: true);

    private static string FormatarTempo(long segundos)
    {
        var intervalo = TimeSpan.FromSeconds(segundos);
        return intervalo.TotalDays >= 1
            ? $"{(int)intervalo.TotalDays}d {intervalo.Hours}h {intervalo.Minutes}m"
            : $"{intervalo.Hours}h {intervalo.Minutes}m {intervalo.Seconds}s";
    }
}
