import argparse
import json
import random
import threading
import time
import urllib.request


def enviar(servidor, chave, carga):
    requisicao = urllib.request.Request(
        f"{servidor.rstrip('/')}/api/medicoes",
        data=json.dumps(carga).encode("utf-8"),
        headers={"Content-Type": "application/json", "X-Chave-Agente": chave},
        method="POST",
    )
    with urllib.request.urlopen(requisicao, timeout=15) as resposta:
        return resposta.status


def agente(indice, servidor, chave, intervalo, parar):
    nome = f"SIM-PC-{indice:02d}"
    ip = f"192.168.0.{100 + indice}"
    memoria_total = random.choice([8192, 16384, 32768])
    disco_total = random.choice([256.0, 476.9, 931.5])
    disco_percentual = random.uniform(35, 80)
    inicio = time.time()

    while not parar.is_set():
        cpu = min(100, max(2, random.gauss(35, 20)))
        memoria_percentual = min(100, max(10, random.gauss(55, 15)))
        disco_percentual = min(99, max(10, disco_percentual + random.uniform(-0.2, 0.3)))

        carga = {
            "nome": nome,
            "enderecoIp": ip,
            "sistemaOperacional": "Microsoft Windows 10.0.19045 (simulado)",
            "cpuPercentual": round(cpu, 2),
            "memoriaPercentual": round(memoria_percentual, 2),
            "memoriaTotalMb": memoria_total,
            "memoriaUsadaMb": round(memoria_total * memoria_percentual / 100, 2),
            "discoPercentual": round(disco_percentual, 2),
            "discoTotalGb": disco_total,
            "discoUsadoGb": round(disco_total * disco_percentual / 100, 2),
            "tempoAtividadeSegundos": int(time.time() - inicio) + indice * 3600,
        }

        try:
            enviar(servidor, chave, carga)
            print(f"[{nome}] CPU {carga['cpuPercentual']:.1f}% | MEM {carga['memoriaPercentual']:.1f}% | DISCO {carga['discoPercentual']:.1f}%")
        except Exception as erro:
            print(f"[{nome}] falha: {erro}")

        parar.wait(intervalo)


def main():
    parser = argparse.ArgumentParser(description="Simulador de agentes do Monitor de Rede")
    parser.add_argument("--servidor", default="http://localhost:5080")
    parser.add_argument("--chave", default="monitor-rede-local")
    parser.add_argument("--computadores", type=int, default=3)
    parser.add_argument("--intervalo", type=int, default=15)
    argumentos = parser.parse_args()

    parar = threading.Event()
    threads = [
        threading.Thread(
            target=agente,
            args=(i + 1, argumentos.servidor, argumentos.chave, argumentos.intervalo, parar),
            daemon=True,
        )
        for i in range(argumentos.computadores)
    ]

    for t in threads:
        t.start()

    print(f"Simulando {argumentos.computadores} computadores contra {argumentos.servidor}. Ctrl+C para encerrar.")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        parar.set()
        print("\nEncerrado.")


if __name__ == "__main__":
    main()
