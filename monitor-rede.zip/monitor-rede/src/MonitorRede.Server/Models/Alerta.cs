namespace MonitorRede.Server.Models;

public class Alerta
{
    public long Id { get; set; }
    public int ComputadorId { get; set; }
    public Computador? Computador { get; set; }

    public string Tipo { get; set; } = string.Empty;
    public string Mensagem { get; set; } = string.Empty;
    public double Valor { get; set; }
    public DateTime DataHora { get; set; }
    public bool Ativo { get; set; }
    public DateTime? DataHoraResolucao { get; set; }
}
