<div align="center">

# Monitor de Rede

**Sistema de monitoramento centralizado de computadores em rede local**

Agente de coleta · Servidor central com API Web · Painel web de visualização

![.NET](https://img.shields.io/badge/.NET-8.0-512BD4?style=flat-square&logo=dotnet&logoColor=white)
![ASP.NET Core](https://img.shields.io/badge/ASP.NET%20Core-Minimal%20API-512BD4?style=flat-square)
![SQLite](https://img.shields.io/badge/SQLite-Banco%20local-003B57?style=flat-square&logo=sqlite&logoColor=white)
![Windows](https://img.shields.io/badge/Windows-Service-0078D6?style=flat-square&logo=windows&logoColor=white)
![Licença](https://img.shields.io/badge/licen%C3%A7a-MIT-green?style=flat-square)

</div>

---

## Sobre o projeto

Este sistema realiza o **monitoramento centralizado de computadores conectados a uma rede local**. A solução é composta por três componentes independentes, separando as responsabilidades de coleta, processamento e apresentação dos dados:

| Componente | Função |
|---|---|
| **Agente** | Instalado nos computadores monitorados. Coleta periodicamente informações técnicas e envia ao servidor via HTTP. |
| **Servidor central** | API Web em ASP.NET Core. Recebe os dados, identifica os computadores, armazena as medições em banco SQLite e avalia os alertas. |
| **Painel web** | Interface centralizada para visualizar estado, indicadores, histórico e alertas sem consultar cada computador individualmente. |

### Indicadores coletados

- Utilização do processador (%)
- Utilização da memória RAM (% / MB)
- Utilização do armazenamento (% / GB)
- Endereço IP
- Nome do computador
- Tempo de atividade (uptime)
- Última comunicação registrada

---

## Arquitetura

```
┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│  Computador A    │     │  Computador B    │     │  Computador N    │
│  MonitorRede     │     │  MonitorRede     │     │  MonitorRede     │
│  .Agent          │     │  .Agent          │     │  .Agent          │
└────────┬─────────┘     └────────┬─────────┘     └────────┬─────────┘
         │                        │                        │
         └────────────── HTTP POST /api/medicoes ──────────┘
                                  │
                                  ▼
                   ┌──────────────────────────────┐
                   │   MonitorRede.Server         │
                   │   ASP.NET Core Minimal API   │
                   │   ├── Registro de medições   │
                   │   ├── Avaliação de alertas   │
                   │   └── Verificador offline    │
                   └──────────────┬───────────────┘
                                  │
                   ┌──────────────┴───────────────┐
                   │                              │
                   ▼                              ▼
          ┌─────────────────┐          ┌─────────────────────┐
          │  SQLite         │          │  Painel Web         │
          │  monitor.db     │          │  http://host:5080   │
          └─────────────────┘          └─────────────────────┘
```

### Modelo de dados

| Tabela | Conteúdo |
|---|---|
| `Computadores` | Cadastro dos equipamentos: nome, IP, sistema operacional, primeira e última comunicação. |
| `Medicoes` | Histórico das coletas: CPU, memória, disco e tempo de atividade por data/hora. |
| `Alertas` | Eventos de uso elevado de recursos e perda de comunicação, com abertura e resolução. |

---

## Funcionalidades

- Coleta periódica automática de indicadores técnicos
- Transmissão via requisições HTTP na rede local
- Armazenamento estruturado em banco de dados SQLite
- Identificação automática de estado **online / offline** com base na comunicação periódica
- Histórico de indicadores por computador (1h, 6h, 24h, 7 dias) com gráficos
- Alertas de uso elevado de CPU, memória e armazenamento com limites configuráveis
- Alertas de perda de comunicação
- Painel web responsivo com atualização automática a cada 15 segundos
- Filtro por nome ou endereço IP
- **Exportação CSV de medições e alertas por período**, com filtro por computador e tipo
- Instalação como **serviço do Windows** em ambos os componentes
- Limpeza automática do histórico conforme período de retenção

---

## Requisitos

**Para desenvolvimento**
- [.NET SDK 8.0](https://dotnet.microsoft.com/download/dotnet/8.0) ou superior
- Windows 10/11 ou Windows Server (coleta via contadores de desempenho do Windows)

**Para execução**
- Nenhum. Os executáveis publicados são *self-contained* e não exigem .NET instalado.
- Permissão de administrador para instalar os serviços.
- Comunicação liberada na porta do servidor (padrão `5080`).

---

## Instalação rápida

### 1. Clonar e publicar

```powershell
git clone https://github.com/<seu-usuario>/monitor-rede.git
cd monitor-rede
powershell -ExecutionPolicy Bypass -File .\scripts\publicar.ps1
```

São gerados dois pacotes independentes:

```
publicado\
├── servidor\     → instalar no computador central
└── agente\       → copiar para cada computador monitorado
```

### 2. Instalar o servidor (computador central)

Abra o **PowerShell como Administrador** dentro de `publicado\servidor`:

```powershell
.\instalar-servidor.ps1
```

O script instala o serviço `MonitorRedeServer`, cria a regra de firewall e exibe o endereço do painel:

```
Painel local : http://localhost:5080
Painel rede  : http://192.168.0.10:5080
```

Para usar outra porta:

```powershell
.\instalar-servidor.ps1 -Porta 8080
```

### 3. Instalar o agente (computadores monitorados)

Copie a pasta `publicado\agente` para cada computador e execute como **Administrador**:

```powershell
.\instalar-agente.ps1 -UrlServidor "http://192.168.0.10:5080"
```

Parâmetros opcionais:

```powershell
.\instalar-agente.ps1 `
    -UrlServidor "http://192.168.0.10:5080" `
    -IntervaloSegundos 30 `
    -NomePersonalizado "LAB-01" `
    -UnidadeDisco "D:\" `
    -ChaveAgente "minha-chave"
```

> Em poucos segundos o computador aparece no painel.

---

## Execução em modo desenvolvimento

```powershell
# Terminal 1 — servidor
dotnet run --project src\MonitorRede.Server

# Terminal 2 — agente apontando para o servidor local
dotnet run --project src\MonitorRede.Agent
```

Painel disponível em `http://localhost:5080`.

---

## Configuração

### Servidor — `appsettings.json`

```json
{
  "Urls": "http://0.0.0.0:5080",
  "Monitoramento": {
    "SegundosParaOffline": 90,
    "LimiteCpu": 90,
    "LimiteMemoria": 90,
    "LimiteDisco": 90,
    "DiasRetencaoHistorico": 30,
    "ChaveAgente": "monitor-rede-local"
  }
}
```

| Parâmetro | Descrição |
|---|---|
| `SegundosParaOffline` | Tempo sem comunicação para considerar o computador indisponível. |
| `LimiteCpu` / `LimiteMemoria` / `LimiteDisco` | Percentuais que disparam alerta de uso elevado. |
| `DiasRetencaoHistorico` | Período de retenção das medições antigas. |
| `ChaveAgente` | Chave compartilhada enviada pelos agentes no cabeçalho `X-Chave-Agente`. |

### Agente — `appsettings.json`

```json
{
  "Agente": {
    "UrlServidor": "http://192.168.0.10:5080",
    "IntervaloSegundos": 30,
    "ChaveAgente": "monitor-rede-local",
    "NomePersonalizado": "",
    "UnidadeDisco": "C:\\"
  }
}
```

> A chave do agente deve ser idêntica à configurada no servidor.
> Após alterar a configuração, reinicie o serviço: `Restart-Service MonitorRedeAgent`.

---

## API

Base: `http://<servidor>:5080`

| Método | Rota | Descrição |
|---|---|---|
| `POST` | `/api/medicoes` | Recebe uma medição enviada por um agente. Requer `X-Chave-Agente`. |
| `GET` | `/api/computadores` | Lista computadores com estado atual e últimos indicadores. |
| `GET` | `/api/computadores/{id}/historico?horas=6` | Histórico de medições do computador. |
| `DELETE` | `/api/computadores/{id}` | Remove o computador e seu histórico. |
| `GET` | `/api/alertas?ativos=true&limite=100` | Lista alertas. |
| `GET` | `/api/visao-geral` | Totais consolidados e médias. |
| `GET` | `/api/exportacao/medicoes.csv` | Exporta medições do período em CSV. |
| `GET` | `/api/exportacao/alertas.csv` | Exporta alertas do período em CSV. |
| `GET` | `/api/exportacao/previa` | Quantidade de registros do período, sem baixar o arquivo. |
| `GET` | `/api/configuracao` | Parâmetros de monitoramento em uso. |
| `GET` | `/api/saude` | Verificação de disponibilidade do servidor. |

**Exemplo de envio**

```bash
curl -X POST http://192.168.0.10:5080/api/medicoes \
  -H "Content-Type: application/json" \
  -H "X-Chave-Agente: monitor-rede-local" \
  -d '{
    "nome": "LAB-01",
    "enderecoIp": "192.168.0.21",
    "sistemaOperacional": "Microsoft Windows 10.0.19045",
    "cpuPercentual": 34.5,
    "memoriaPercentual": 61.2,
    "memoriaTotalMb": 16384,
    "memoriaUsadaMb": 10027,
    "discoPercentual": 72.8,
    "discoTotalGb": 476.9,
    "discoUsadoGb": 347.2,
    "tempoAtividadeSegundos": 184320
  }'
```

---

## Exportação de dados

O painel possui a seção **Exportação de dados**, onde é possível definir o período, o computador e o tipo de alerta. Antes de baixar, a prévia informa quantos registros serão exportados.

### Pela interface

1. Informe **data inicial** e **data final**
2. Opcionalmente filtre por computador ou tipo de alerta
3. Escolha o separador
4. Clique em **Baixar medições** ou **Baixar alertas**

### Pela API

```bash
# Medições de um período
curl -OJ "http://192.168.0.10:5080/api/exportacao/medicoes.csv?inicio=2026-03-01&fim=2026-03-31"

# Medições de um único computador
curl -OJ "http://192.168.0.10:5080/api/exportacao/medicoes.csv?inicio=2026-03-01&fim=2026-03-31&computadorId=3"

# Alertas de CPU no período
curl -OJ "http://192.168.0.10:5080/api/exportacao/alertas.csv?inicio=2026-03-01&fim=2026-03-31&tipo=CPU"

# Conferir a quantidade antes de baixar
curl "http://192.168.0.10:5080/api/exportacao/previa?inicio=2026-03-01&fim=2026-03-31"
```

**Parâmetros**

| Parâmetro | Aplica-se a | Descrição |
|---|---|---|
| `inicio` / `fim` | ambos | `aaaa-MM-dd` ou `aaaa-MM-ddTHH:mm`. Interpretados no fuso do servidor. |
| `computadorId` | ambos | Restringe a um computador. |
| `tipo` | alertas | `CPU`, `MEMORIA`, `DISCO` ou `COMUNICACAO`. |
| `ativos` | alertas | `true` exporta apenas alertas ainda em aberto. |
| `separador` | ambos | `pontovirgula` (padrão) ou `virgula`. |

> Sem `inicio`/`fim`, exporta os últimos **7 dias** de medições e **30 dias** de alertas.
> `fim` informado como data pura inclui o dia inteiro.

### Colunas geradas

**`medicoes_<periodo>.csv`**

`DataHoraUtc`, `Computador`, `EnderecoIp`, `CpuPercentual`, `MemoriaPercentual`, `MemoriaUsadaMb`, `MemoriaTotalMb`, `DiscoPercentual`, `DiscoUsadoGb`, `DiscoTotalGb`, `TempoAtividadeSegundos`, `TempoAtividadeFormatado`

**`alertas_<periodo>.csv`**

`DataHoraUtc`, `Computador`, `EnderecoIp`, `Tipo`, `Mensagem`, `Valor`, `Ativo`, `DataHoraResolucaoUtc`, `DuracaoSegundos`, `DuracaoFormatada`

> A coluna `DuracaoSegundos` mede quanto tempo o alerta permaneceu aberto — útil para analisar a confiabilidade do ambiente. Alertas ainda ativos são calculados até o instante da exportação.

### Observações

- Arquivo em **UTF-8 com BOM** e separador `;` por padrão, abrindo direto no Excel em português sem assistente de importação.
- Datas e horas são gravadas em **UTC**, mantendo consistência entre computadores com fusos distintos.
- A geração usa *streaming*: períodos longos não carregam todo o conteúdo em memória.

---

## Testes em rede local

O script `scripts/simular-agentes.py` gera computadores fictícios para validar o painel sem instalar agentes reais:

```bash
python scripts/simular-agentes.py --servidor http://localhost:5080 --computadores 5
```

Para os testes descritos no trabalho, provoque situações controladas:

| Cenário | Como provocar | Resultado esperado |
|---|---|---|
| Uso elevado de CPU | Laço de processamento intenso | Alerta `CPU` e barra vermelha no painel |
| Uso elevado de memória | Alocação de grande volume de RAM | Alerta `MEMORIA` |
| Ocupação de armazenamento | Preenchimento da unidade monitorada | Alerta `DISCO` |
| Interrupção de rede | Parar o serviço ou desconectar o cabo | Estado `OFFLINE` e alerta `COMUNICACAO` |

Após os experimentos, exporte o período correspondente em CSV para montar as tabelas e os gráficos de resultados.

---

## Estrutura do repositório

```
monitor-rede/
├── MonitorRede.sln
├── README.md
├── LICENSE
├── .gitignore
├── src/
│   ├── MonitorRede.Server/
│   │   ├── Data/            Contexto do banco de dados
│   │   ├── Models/          Entidades
│   │   ├── Dtos/            Contratos da API
│   │   ├── Services/        Regras de monitoramento e alertas
│   │   ├── Endpoints/       Rotas da API Web
│   │   ├── wwwroot/         Painel web
│   │   ├── Program.cs
│   │   └── appsettings.json
│   └── MonitorRede.Agent/
│       ├── ColetorMetricas.cs
│       ├── ServicoAgente.cs
│       ├── Program.cs
│       └── appsettings.json
└── scripts/
    ├── publicar.ps1
    ├── instalar-servidor.ps1
    ├── instalar-agente.ps1
    ├── desinstalar-servidor.ps1
    ├── desinstalar-agente.ps1
    └── simular-agentes.py
```

---

## Operação dos serviços

```powershell
# Estado
Get-Service MonitorRedeServer, MonitorRedeAgent

# Reiniciar
Restart-Service MonitorRedeAgent

# Registros no Visualizador de Eventos
Get-EventLog -LogName Application -Source MonitorRedeAgent -Newest 20
```

**Desinstalação**

```powershell
.\desinstalar-agente.ps1
.\desinstalar-servidor.ps1 -ManterDados
```

---

## Solução de problemas

| Situação | Verificação |
|---|---|
| Computador não aparece no painel | Confirme `UrlServidor`, a porta liberada no firewall e se a chave do agente é igual à do servidor. |
| Resposta `401` | Chave divergente entre agente e servidor. |
| CPU sempre em 0% | Adicione a conta do serviço ao grupo **Usuários do Monitor de Desempenho** ou execute o serviço como `LocalSystem`. |
| Painel não abre na rede | Verifique `Urls` em `appsettings.json` e a regra de firewall da porta. |
| Banco de dados | Arquivo `dados\monitor.db` dentro da pasta de instalação do servidor. |

---

## Privacidade dos dados

A coleta é restrita a informações técnicas necessárias ao monitoramento. **Não são coletados** dados pessoais dos usuários, arquivos pessoais ou conteúdo das atividades realizadas nos equipamentos.

---

## Licença

Distribuído sob a licença MIT. Consulte o arquivo [LICENSE](LICENSE).

---

<div align="center">
Desenvolvido como Trabalho de Conclusão de Curso
</div>
